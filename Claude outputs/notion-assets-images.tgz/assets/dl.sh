#!/bin/bash
# usage: dl.sh NN URLFILE  (URLFILE: lines "kind<TAB>url")
NN=$1; F=$2; D=/tmp/claude-0/-home-claude/2303b7b3-f364-5521-94ab-74d4678451e0/scratchpad/notion/assets/$NN
mkdir -p $D; i=0
while IFS=$'\t' read -r kind url; do
  [ -z "$url" ] && continue
  i=$((i+1)); idx=$(printf %02d $i)
  path=${url%%\?*}; name=$(basename "$path"); name=$(printf '%b' "${name//%/\\x}")
  out="$D/$idx-$name"
  code=$(curl -sS --cacert /root/.ccr/ca-bundle.crt -o "$out" -w '%{http_code}' "$url")
  sz=$(stat -c %s "$out" 2>/dev/null || echo 0)
  echo -e "$NN\t$kind\t$i\t$path\t$out\t$sz\t$code\t$(file -b "$out" | cut -c1-40)"
done < "$F"
